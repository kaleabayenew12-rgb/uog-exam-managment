import { apiService } from './apiService';

export interface ProfileData {
  name: string;
  phone: string;
  bio: string;
  avatar?: string;
}

export interface ProfileResponse {
  success: boolean;
  data?: ProfileData;
  message?: string;
}

class ProfileApiService {
  async getProfile(): Promise<ProfileResponse> {
    return apiService.get('/profile');
  }

  async updateProfile(profileData: ProfileData): Promise<ProfileResponse> {
    return apiService.put('/profile', profileData);
  }

  async updateProfileWithAvatar(profileData: ProfileData, avatarFile?: File): Promise<ProfileResponse> {
    if (avatarFile) {
      const formData = new FormData();
      formData.append('name', profileData.name);
      formData.append('phone', profileData.phone);
      formData.append('bio', profileData.bio);
      formData.append('avatar', avatarFile);
      
      return apiService.put('/profile/avatar', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } else {
      return this.updateProfile(profileData);
    }
  }

  async uploadAvatar(avatarFile: File): Promise<ProfileResponse> {
    const formData = new FormData();
    formData.append('avatar', avatarFile);
    
    return apiService.post('/profile/avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }
}

export const profileApiService = new ProfileApiService();
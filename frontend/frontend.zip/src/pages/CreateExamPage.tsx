import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { ExamForm } from '../components/Exams/ExamForm';
import { Exam } from '../types';

interface CreateExamPageProps {
  onNavigate: (route: string) => void;
}

export const CreateExamPage: React.FC<CreateExamPageProps> = ({ onNavigate }) => {
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async (examData: Partial<Exam>) => {
    setIsSaving(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Saving exam:', examData);
      
      // Show success message
      alert('Exam saved successfully!');
      
      // Navigate back to exams list
      onNavigate('exams');
    } catch (error) {
      console.error('Error saving exam:', error);
      alert('Error saving exam. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSendToDepartment = async (examId: string, departments: string[], message: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log('Sending exam to departments:', { examId, departments, message });
      
      // Show success message
      alert('Exam sent to department for approval!');
      
      // Navigate back to exams list
      onNavigate('exams');
    } catch (error) {
      console.error('Error sending exam:', error);
      alert('Error sending exam. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => onNavigate('exams')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Create New Exam</h1>
              <p className="text-sm text-gray-600">Build your exam with questions and settings</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="py-6">
        <ExamForm 
          onSave={handleSave}
          onSendToDepartment={handleSendToDepartment}
        />
      </div>

      {/* Loading Overlay */}
      {isSaving && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 flex items-center space-x-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <span className="text-gray-900">Saving exam...</span>
          </div>
        </div>
      )}
    </div>
  );
};